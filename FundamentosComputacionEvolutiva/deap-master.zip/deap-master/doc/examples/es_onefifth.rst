.. _one-fifth:

==============
One Fifth Rule
==============
Soon!

.. The one fifth rule consists in changing the mutation strength when 